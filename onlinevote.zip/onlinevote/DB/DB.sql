/*
SQLyog - Free MySQL GUI v5.19
Host - 5.0.15-nt : Database - election_polling
*********************************************************************
Server version : 5.0.15-nt
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `election_polling`;

USE `election_polling`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `m_admin` */

DROP TABLE IF EXISTS `m_admin`;

CREATE TABLE `m_admin` (
  `Admin_code` int(10) NOT NULL auto_increment,
  `Admin_id` varchar(50) NOT NULL,
  `Admin_pwd` varchar(50) NOT NULL,
  PRIMARY KEY  (`Admin_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_admin` */

insert into `m_admin` (`Admin_code`,`Admin_id`,`Admin_pwd`) values (1,'officer','officer');

/*Table structure for table `m_booth_manager` */

DROP TABLE IF EXISTS `m_booth_manager`;

CREATE TABLE `m_booth_manager` (
  `B_code` int(5) NOT NULL auto_increment,
  `B_M_name` varchar(50) NOT NULL,
  `B_M_userid` varchar(50) NOT NULL,
  `B_M_pwd` varchar(50) NOT NULL,
  `E_D_code` int(10) NOT NULL,
  `B_reference_no` varchar(50) NOT NULL,
  PRIMARY KEY  (`B_code`),
  KEY `FK_m_booth_manager` (`E_D_code`),
  CONSTRAINT `m_booth_manager_ibfk_1` FOREIGN KEY (`E_D_code`) REFERENCES `m_electoral_district` (`E_D_code`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_booth_manager` */

/*Table structure for table `m_candidate` */

DROP TABLE IF EXISTS `m_candidate`;

CREATE TABLE `m_candidate` (
  `C_code` int(10) NOT NULL auto_increment,
  `C_name` varchar(50) NOT NULL,
  `C_address` varchar(50) NOT NULL,
  `C_age` int(10) NOT NULL,
  `C_symbol` varchar(50) NOT NULL,
  `E_D_code` int(10) NOT NULL,
  `C_remarks` varchar(200) NOT NULL,
  `C_party` varchar(50) NOT NULL,
  PRIMARY KEY  (`C_code`),
  KEY `FK_m_candidate` (`E_D_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_candidate` */

/*Table structure for table `m_control_manager` */

DROP TABLE IF EXISTS `m_control_manager`;

CREATE TABLE `m_control_manager` (
  `C_M_code` int(10) NOT NULL auto_increment,
  `C_M_name` varchar(50) NOT NULL,
  `C_M_userid` varchar(50) NOT NULL,
  `C_M_pwd` varchar(50) NOT NULL,
  PRIMARY KEY  (`C_M_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_control_manager` */

/*Table structure for table `m_electoral_district` */

DROP TABLE IF EXISTS `m_electoral_district`;

CREATE TABLE `m_electoral_district` (
  `E_D_code` int(10) NOT NULL auto_increment,
  `E_D_name` varchar(50) NOT NULL,
  `E_D_district` varchar(50) NOT NULL,
  `E_D_state` varchar(50) NOT NULL,
  PRIMARY KEY  (`E_D_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_electoral_district` */

/*Table structure for table `m_voters` */

DROP TABLE IF EXISTS `m_voters`;

CREATE TABLE `m_voters` (
  `V_code` int(50) NOT NULL auto_increment,
  `V_id_no` varchar(50) NOT NULL,
  `V_name` varchar(50) NOT NULL,
  `V_address` varchar(100) default NULL,
  `V_sex` char(10) default NULL,
  `V_age` varchar(50) NOT NULL,
  `B_code` int(10) NOT NULL,
  `V_image` varchar(50) default NULL,
  `V_position` varchar(20) NOT NULL,
  `V_Vote_status` varchar(20) NOT NULL,
  PRIMARY KEY  (`V_code`,`V_id_no`),
  KEY `FK_m_voters` (`B_code`),
  CONSTRAINT `m_voters_ibfk_1` FOREIGN KEY (`B_code`) REFERENCES `m_booth_manager` (`B_code`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_voters` */

/*Table structure for table `m_votes` */

DROP TABLE IF EXISTS `m_votes`;

CREATE TABLE `m_votes` (
  `T_no` int(10) NOT NULL auto_increment,
  `C_code` int(10) NOT NULL,
  `B_code` int(50) NOT NULL,
  `E_D_code` int(10) NOT NULL,
  `No_votes` varchar(10000) NOT NULL,
  PRIMARY KEY  (`T_no`,`C_code`,`B_code`,`E_D_code`),
  KEY `FK_m_votes` (`C_code`),
  KEY `FK_m_votes-1` (`B_code`),
  KEY `FK_m_votes-2` (`E_D_code`),
  CONSTRAINT `m_votes_ibfk_1` FOREIGN KEY (`C_code`) REFERENCES `m_candidate` (`C_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `m_votes_ibfk_2` FOREIGN KEY (`B_code`) REFERENCES `m_booth_manager` (`B_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `m_votes_ibfk_3` FOREIGN KEY (`E_D_code`) REFERENCES `m_electoral_district` (`E_D_code`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_votes` */

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
